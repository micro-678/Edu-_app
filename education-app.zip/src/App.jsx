import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Education Assistant</h1>
      <p>Upload your study material and get quizzes, flashcards, and revision help.</p>
    </div>
  );
}

export default App;
